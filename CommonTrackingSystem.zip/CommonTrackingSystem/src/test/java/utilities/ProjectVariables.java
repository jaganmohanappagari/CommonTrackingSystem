package utilities;

public class ProjectVariables {

	
	    //########################################## BROWSER SYNC TIME VARIABLES ###########################################################################//
		 
		public static final int MID_TIME_OUT = 5;

		public static final int MIN_TIME_OUT = 4;

		public static final int MAX_TIME_OUT = 10;

		public static long TImeout_2_Seconds = 2;

		public static final int TImeout_5_Seconds = 5;
}
