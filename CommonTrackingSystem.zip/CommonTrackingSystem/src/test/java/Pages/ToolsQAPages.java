package Pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import utilities.SeleniumUtils;

import static utilities.GenericUtils.Verify;

public class ToolsQAPages extends SeleniumUtils {

    @FindBy(id="firstName")
    public WebElementFacade fistName;

    @FindBy(id="lastName")
    public WebElementFacade lastName;

    @FindBy(id="userEmail")
    public WebElementFacade userEmail;

    @FindBy(xpath="//input[@value='Male']")
    public WebElementFacade Male;

    @FindBy(id="userNumber")
    public WebElementFacade userNumber;

    String sMale = "//input[@value='Male']";

    public void EnterStudentRegistratonFormDetails(String sFirst_name, String sLast_name, String sEmail, String sGender, String sMobileNumber) throws InterruptedException {
        Enter_given_Text_Element(fistName,sFirst_name);
        Enter_given_Text_Element(lastName,sLast_name);
        Enter_given_Text_Element(userEmail,sEmail);
        Enter_given_Text_Element(userNumber,sMobileNumber);
    }
}
