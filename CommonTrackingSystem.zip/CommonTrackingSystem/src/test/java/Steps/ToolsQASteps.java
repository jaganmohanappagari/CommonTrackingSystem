package Steps;

import Pages.ToolsQAPages;
import net.thucydides.core.annotations.Step;
import org.fluentlenium.core.annotation.Page;

import static net.thucydides.core.webdriver.ThucydidesWebDriverSupport.getDriver;

public class ToolsQASteps {
    @Page
    ToolsQAPages toolsQAPages;

    @Step
    public void LaunchApplication(String sURL) {
        getDriver().manage().window().maximize();
        getDriver().get(sURL);
    }

    @Step
    public void EnterStudentRegistrationFormDetails(String sFirst_name, String sLast_name, String sEmail, String sGender, String sMobileNumber) throws InterruptedException {
        toolsQAPages.EnterStudentRegistratonFormDetails(sFirst_name,sLast_name,sEmail,sGender,sMobileNumber);
    }
}
