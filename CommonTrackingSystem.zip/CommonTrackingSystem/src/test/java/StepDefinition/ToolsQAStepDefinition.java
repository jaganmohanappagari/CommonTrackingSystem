package StepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import Steps.ToolsQASteps;
import java.util.List;
import java.util.Map;


public class ToolsQAStepDefinition {

    @Managed
    WebDriver driver;

    @Steps
    ToolsQASteps toolsQASteps;

    @Given("user launch the ToolsQA Application")
    public void user_launch_the_tools_qa_application(List<Map<String,String>> values) {
        for(Map<String,String>value: values){
            String sURL = StringUtils.defaultString(value.get("URL"));
            toolsQASteps.LaunchApplication(sURL);
        }
    }

    @When("user fills the Student Registration form")
    public void user_fills_the_student_registration_form(List<Map<String,String>> values) throws InterruptedException {
        for(Map<String,String>value: values){
            String sFirst_Name = StringUtils.defaultString(value.get("First_Name"));
            String sLast_Name = StringUtils.defaultString(value.get("Last_Name"));
            String sEmail = StringUtils.defaultString(value.get("Email"));
            String sGender = StringUtils.defaultString(value.get("Gender"));
            String sMobileNumber = StringUtils.defaultString(value.get("MobileNumber"));
            toolsQASteps.EnterStudentRegistrationFormDetails(sFirst_Name,sLast_Name,sEmail,sGender,sMobileNumber);
        }
    }

}
